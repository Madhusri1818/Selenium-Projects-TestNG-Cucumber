package com.webelements;

import org.openqa.selenium.By;

import com.utilites.ActionMethods;

import io.cucumber.core.logging.Logger;
import io.cucumber.core.logging.LoggerFactory;

public class WebElementsPage {
	public static final Logger logger = LoggerFactory.getLogger(WebElementsPage.class);
	
	
	By username=By.id("input-username");
	By password=By.id("input-password");
	By close_btn=By.xpath("//button[@class='btn-close']");
	By loginButton = By.xpath("//button[text()=' Login' and @type='submit']");
	
	
	public void EnterData(String User,String pwd) {
		
		ActionMethods.refresh();
		ActionMethods.sendKeys(username, User);
		ActionMethods.sendKeys(password, pwd);
	}
	
	public void Login() throws Exception {
		Thread.sleep(2000);
		ActionMethods.clickJS(loginButton);
		Thread.sleep(4000);
		ActionMethods.click(close_btn);
	}
}
