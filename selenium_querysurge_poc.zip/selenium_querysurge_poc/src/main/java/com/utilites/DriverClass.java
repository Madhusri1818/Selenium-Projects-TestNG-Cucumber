package com.utilites;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverClass {

	private static ThreadLocal<WebDriver> currentDriver ;

	public static WebDriver driver = null;
	

	@SuppressWarnings("deprecation")
	public static WebDriver getDriver(String browser) {

		try {
			if (browser.toUpperCase().contains("FIREFOX")) {
				WebDriverManager.firefoxdriver().setup();
				driver=new FirefoxDriver();
				}
			if (browser.toUpperCase().contains("CHROME")) {
				WebDriverManager.chromedriver().setup();
				driver=new ChromeDriver();
			}
			if (browser.toUpperCase().contains("IE")) {
				WebDriverManager.iedriver().setup();
				driver=new InternetExplorerDriver();
			}
			if (browser.toUpperCase().contains("EDGE")) {
				WebDriverManager.edgedriver().setup();
				driver=new EdgeDriver();
			}
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get(Config.getPropertyValue("url"));			
			driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		}catch(Exception e){
			e.printStackTrace();
		}
		return driver;
	}
	
	public static WebDriver getcurrentDriver() {
		//currentDriver = new ThreadLocal<WebDriver>();
		return driver;
	}
	
	
	
	
	
}



