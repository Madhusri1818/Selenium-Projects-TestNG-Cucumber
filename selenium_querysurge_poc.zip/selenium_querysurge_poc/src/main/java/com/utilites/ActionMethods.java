package com.utilites;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.Date;



public class ActionMethods {

	// static WebDriver driver = DriverClass.getcurrentDriver();
	static WebDriver driver;
	public static SimpleDateFormat sdf;


	public static String getScreenShot(String imageName) throws IOException {
		if (imageName.equals("")) {
			imageName = "SS";
		}
		String imagelocation = "";
		sdf = new SimpleDateFormat("dd-MM-YYYY-hh-mm-SS-SSS");
		String actualImageName = imagelocation + imageName + "" + sdf.format(new Date()) + ".mp4"; // for video file
		// String actualImageName = imagelocation+imageName+""+sdf.format(new
		// Date())+".png";

		File sourceFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File destFile = new File(actualImageName);
		FileUtils.copyFile(sourceFile, destFile);
		return actualImageName;
	}

	public static void select(WebElement elem, String keysToSend) {
		try {
			Select obj = new Select(elem);
			obj.selectByVisibleText(keysToSend);
			Thread.sleep(1500);
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			e.printStackTrace();
		}
	}

	public static void waitForPageLoad() {
		driver = DriverClass.getcurrentDriver();
		ExpectedCondition<Boolean> expect = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			wait.until(expect);
		} catch (Exception e) {
			Assert.fail();
			e.printStackTrace();
		}
	}

	public static WebElement findElement(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			return driver.findElement(by);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			E.printStackTrace();
			return null;
		}
	}

	public static boolean isElementPresent(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.findElement(by);
			return true;
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			return false;
		}
	}

	public static boolean isElementPresent(String element) {
		try {
			WebElement elem = findElement(By.xpath(element));
			elem.isEnabled();
			return true;
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			return false;
		}
	}

	public static boolean isElementPresentWrtText(String value) {
		try {
			String xpath = "//*[contains(text(),'" + value + "')]";
			WebElement elem = DriverClass.getcurrentDriver().findElement(By.xpath(xpath));
			elem.isEnabled();
			return true;
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			return false;
		}
	}

	public static boolean isElementPresent(WebElement elem) {
		try {
			return elem.isEnabled();
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			return false;
		}
	}

	public static List<WebElement> findElements(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			return driver.findElements(by);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			return null;
		}
	}

	/**
	 * Used to find multiple elements in Payments module
	 */
	public static ArrayList<String> findElementsText(By by) {
		try {
			ArrayList<String> mylist = new ArrayList<String>();
			List<WebElement> elems = findElements(by);
			for (WebElement elem : elems) {
				mylist.add(elem.getText());
			}
			return mylist;
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			return null;
		}
	}

	public static void click(String element) {
		try {
			WebElement elem = findElement(By.xpath(element));
			//highlight(elem);
			elem.click();
		} catch (Exception E) {
			Assert.fail();
			E.printStackTrace();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void click(By by) {
		try {
			WebElement elem = findElement(by);
			//highlight(elem);
			elem.click();
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void mouseHover(String element) {
		try {
			WebElement elem = findElement(By.xpath(element));
			Actions actions = new Actions(DriverClass.getcurrentDriver());
			actions.moveToElement(elem).build().perform();
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void mouseHoverClick(String element) {
		try {
			WebElement elem = findElement(By.xpath(element));
			Actions actions = new Actions(DriverClass.getcurrentDriver());
			actions.moveToElement(elem).click().build().perform();
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void doubleClick(String element) {
		try {
			WebElement elem = findElement(By.xpath(element));
			Actions actions = new Actions(DriverClass.getcurrentDriver());
			actions.moveToElement(elem).doubleClick().build().perform();
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickThrowError(By by, String elemname) {
		driver = DriverClass.getcurrentDriver();
		WebElement elem = driver.findElement(by);// findElement(by);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", elem);
	}

	public static void clickJS(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement elem = findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", elem);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickJS(By by, String elemname) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement elem = findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", elem);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickJS(WebElement elem, String elemname) {
		try {
			driver = DriverClass.getcurrentDriver();
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", elem);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickJSNoError(By by, String elemname) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement elem = driver.findElement(by);// findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", elem);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void click(By by, String elemname) {
		try {
			waitClickable(by);
			WebElement elem = findElement(by);
			elem.click();
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickNoError(By by, String elemname) {
		try {
			driver = DriverClass.getcurrentDriver();
			Thread.sleep(10000);
			driver.findElement(by).click();
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void click(WebElement elem) {
		try {
			elem.click();
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void click(WebElement elem, String elementname) {
		try {
			//highlight(elem);
			elem.click();
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickbyValue(String value) {
		try {
			String xpath = "//*[contains(text(),'" + value + "')]";
			WebElement elem = DriverClass.getcurrentDriver().findElement(By.xpath(xpath));
			elem.click();
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clickbyValueWithdiv(String value) {
		try {
			String xpath = "//div[contains(text(),'" + value + "')]";
			WebElement elem = DriverClass.getcurrentDriver().findElement(By.xpath(xpath));
			elem.click();
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static Boolean ObjectExist(By LocatorValue) throws Exception, FileNotFoundException, IOException {
		Boolean ObjectExist = null;

		driver = DriverClass.getcurrentDriver();

		waitVisibleNoError(LocatorValue, Integer.parseInt(Config.getPropertyValue("timeout")));
		try {
			Thread.sleep(1500);
			if (driver.findElement(LocatorValue).isDisplayed()) {
				ObjectExist = true;
				System.out.println(ObjectExist);
			} else
				ObjectExist = false;
		} catch (Exception E) {
			// ObjectExist = false;
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
		return ObjectExist;
	}
public static void clearbyKeys(By by) {
	waitVisible(by);
	WebElement t = findElement(by);
	t.sendKeys(Keys.CONTROL+"a");
	t.sendKeys(Keys.DELETE);
	
	
}
	public static void sendKeys(By by, String keysToSend) {
		try {
			waitVisible(by);
			WebElement t = findElement(by);
			t.click();
			t.sendKeys(keysToSend);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void sendKeys(String string, String keysToSend) {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.findElement(By.xpath((string))).sendKeys(keysToSend);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void sendKeysEnter(By by, String keysToSend) {
		try {
			WebElement t = findElement(by);
			t.sendKeys(keysToSend, Keys.ENTER);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void uploadFile(String fileName) {
		try {
			StringSelection stringSelection = new StringSelection(fileName);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(stringSelection, stringSelection);

			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static int getCsvRowCount(String fileName) throws IOException {
		InputStream is = new BufferedInputStream(new FileInputStream(fileName));
		try {
			byte[] c = new byte[1024];
			int count = 0;
			int readChars = 0;
			boolean empty = true;
			while ((readChars = is.read(c)) != -1) {
				empty = false;
				for (int i = 0; i < readChars; ++i) {
					if (c[i] == '\n') {
						++count;
					}
				}
			}
			return (count == 0 && !empty) ? 1 : count;
		} finally {
			is.close();
		}
	}

	public static void sendKeys(WebElement elem, String keysToSend) {
		try {
			if ((keysToSend != null) | (keysToSend != "")) {
				elem.sendKeys(keysToSend);
			}
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void waitClick(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(by));
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void waitVisible(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			System.out.println("");
			Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void waitVisible(By by, int sec) {
		try {
			driver = DriverClass.getcurrentDriver();
			Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void waitVisible(By by, String name) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void waitInVisible(By by, String name) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void waitClickable(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(by));
			System.out.println("Element is clickable " + by);
		} catch (Exception e) {
			Assert.fail();
			
		}
	}

	public static void waitClickable(By by, String elemname) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(by));
		} catch (Exception e) {
			Assert.fail();
			
		}

	}

	public static boolean waitVisibleNoError(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// WebDriverWait wait = new WebDriverWait(driver,
			// Integer.parseInt(ProjectConfig.getPropertyValue("timeout")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			return true;
		} catch (Exception e) {
			// TestReport.log(LogStatus.ERROR, "Element not visible");
			Assert.fail();
			return false;
		}
	}

	public static void waitVisibleNoError(By by, int sec) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// WebDriverWait wait = new WebDriverWait(driver,
			// Integer.parseInt(ProjectConfig.getPropertyValue("timeout")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			// TestReport.log(LogStatus.ERROR, "Element not visible");
			Assert.fail();
		}
	}

	public static void waitForAttribute(By by, String attr, String value) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			// WebDriverWait wait = new WebDriverWait(driver,
			// Integer.parseInt(ProjectConfig.getPropertyValue("timeout")));
			wait.until(ExpectedConditions.attributeContains(by, attr, value));
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void waitClickableNoError(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(by));
		} catch (Exception e) {
			// TestReport.log(LogStatus.ERROR, "Element not visible");
			Assert.fail();
		}
	}

	public static void waitClickableNoError(By by, int time) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(by));
		} catch (Exception e) {
			// TestReport.log(LogStatus.ERROR, "Element not visible");
			Assert.fail();
		}
	}

	public static void waitVisible(WebElement elem) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(elem));
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void waitVisible(String element) {
		try {
			WebElement elem = findElement(By.xpath(element));
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(elem));
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void waitVisible(WebElement elem, String name) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(elem));
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void clearText(WebElement elem) {
		elem.clear();
		// driver=DriverClass.getcurrentDriver();
		// Actions action = new Actions(driver);
		// action.sendKeys(Keys.CONTROL).sendKeys("A").sendKeys(Keys.DELETE).build().perform();
	}

	public static void clearTextUsingBy(String element) {
		WebElement elem = findElement(By.xpath(element));
		elem.clear();
	}

	public static void waitClickable(WebElement elem) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(elem));
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
			
		}
	}

	public static void waitClickable(WebElement elem, String elemname) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(elem));
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void moveClick(By by, String elemname) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(findElement(by)).click().build().perform();
	}

	public static void moveClick(WebElement elem, String elemname) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(elem).click().build().perform();
	}

	public static void moveToElement(By by) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(findElement(by)).perform();
	}

	public static void moveToElement(By by, String elemname) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(findElement(by)).perform();
	}

	public static void moveToElementByXpath(String elemname) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(findElement(By.xpath(elemname))).perform();
	}

	public static void moveToElement(WebElement elem, String elemname) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(elem).perform();
	}

	public static void moveToElementNoLog(WebElement elem) {
		try {
			driver = DriverClass.getcurrentDriver();
			Actions action = new Actions(driver);
			action.moveToElement(elem).perform();
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static void KeyDown() {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.sendKeys(Keys.DOWN).perform();
	}

	public static void moveToElementClickNoFail(By by, String elemname) {
		driver = DriverClass.getcurrentDriver();
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(by)).click().build().perform();
	}

	public static String getText(WebElement policyStatus) {
		try {
			return policyStatus.getText();
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
		return null;
	}

	public static String getTextNoError(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			return driver.findElement(by).getText();
		} catch (Exception E) {
			// TestReport.log(LogStatus.FAIL, "UNABLE TO GET TEXT FROM
			// ELEMENT");
			Assert.fail();
		}
		return null;
	}

	public static String getText(By by, String elem) {
		try {
			return findElement(by).getText();
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
		return null;
	}

	

	/*
	 * public static void assertEquals(By by, String text) { try {
	 * Thread.sleep(2000l); } catch (InterruptedException e1) {
	 * e1.printStackTrace(); } waitVisible(by); try { WebElement elem =
	 * findElement(by); if (elem.getText().trim().equals(text.trim()))
	 * TestReport.log(LogStatus.PASS, "Text is populated in the Element: " + text);
	 * else TestReport.log(LogStatus.FAIL, "Text is not populated in the Element: "
	 * + text); } catch (Exception e) { TestReport.log(LogStatus.ERROR,
	 * "Error in accessing Text"); Assert.fail(); } }
	 */

	public static String getTextOfElement(By by) {
		waitVisible(by);
		try {
			WebElement elem = findElement(by);
			return elem.getText().toString().trim();
		} catch (Exception e) {
			Assert.fail();
			return null;
		}
	}
	
	public static String getTextOfElement(String element) {
		driver = DriverClass.getcurrentDriver();
		waitVisible(By.xpath(element));
		try {
			WebElement elem = driver.findElement(By.xpath(element));
			return elem.getText().toString().trim();
		} catch (Exception e) {
			Assert.fail();
			return null;
		}
	}

	public static boolean assertEqualsComparisonStr(String actVal, String expVal) {
		try {
			boolean flag = false;
			if (expVal.equalsIgnoreCase(actVal)) {
				flag = true;
				// TestReport.log(LogStatus.PASS, "Expected value is equal to
				// Actual value. Actual Value is : " + actVal
				// + " .Expected Value is : " + expVal);
			} else {
				flag = false;
				// TestReport.log(LogStatus.FAIL, "Expected value is not equal
				// to Actual value. Actual Value is : " + actVal
				// + " .Expected Value is : " + expVal);
			}
			return flag;

		} catch (Exception e) {
			Assert.fail();
			return false;
		}
	}


	public static boolean assertContains(By by, String text) {
		try {
			WebElement elem = findElement(by);
			try {
				moveToElementNoLog(elem);

			} catch (Exception e) {

			}
			if (elem.getText().trim().contains(text)) {
				// System.out.println(elem.getText());
				// System.out.println(text);
				return true;
			} else {
				Assert.fail();
				return false;
			}
		} catch (Exception e) {
			Assert.fail();
		}
		return false;
	}

	public static boolean assertContainsOnAttribute(By by, String text, String Attribute) {
		try {
			WebElement elem = findElement(by);
			String attrbdata = elem.getAttribute(Attribute);
			try {
				moveToElementNoLog(elem);
			} catch (Exception e) {

			}
			if (attrbdata.contains(text)) {
				return true;
			} else {
				Assert.fail();
				return false;
			}
		} catch (Exception e) {
			Assert.fail();
		}
		return false;
	}

	public static boolean assertElemsContains(By by, String text) {
		try {
			List<WebElement> elems = findElements(by);
			for (WebElement elem : elems) {
				try {
					moveToElementNoLog(elem);
				} catch (Exception e) {

				}
				if (elem.getText().contains(text)) {
					
					return true;
				}
			}
			Assert.fail();
			return false;
		} catch (Exception e) {
			Assert.fail();
		}
		return false;
	}

	

	public static boolean assertContains(WebElement elem, String text) {
		try {
			if (elem.getText().contains(text)) {
				System.out.println(" - Text is populated in the Element: " + text);
				return true;
			} else {
				Assert.fail();
				return false;
			}
		} catch (Exception e) {
			Assert.fail();
		}
		return false;
	}

	public static void assertContains(By by, String text, String passmsg) {
		try {
			WebElement elem = findElement(by);
			if (elem.getText().contains(text))
				System.out.println(passmsg + " - Text is populated in the Element: " + text);
			else
			Assert.fail();
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void assertContains(String actVal, String expVal) {
		try {
			if (actVal.contains(expVal))
			System.out.println(actVal + " -- Actual Value contains Expected Value -- " + expVal);
			else
			Assert.fail();
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void scrollDown() {
		try {
			driver = DriverClass.getcurrentDriver();
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollTo(0,document.body.scrollHeight)");
			// jse.executeScript("scroll(0, 700);");
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static void scrollUp() {
		try {

			driver = DriverClass.getcurrentDriver();

			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("scroll(0, -250);");
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static void findElementsClick(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			List<WebElement> elm = driver.findElements(by);
			for (WebElement s : elm) {
				clickJS(s);
			}
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static int findElementsCount(String element) {
		int itmcnt = 0;
		try {
			driver = DriverClass.getcurrentDriver();
			List<WebElement> elm = driver.findElements(By.xpath(element));
			for (WebElement s : elm) {
				itmcnt = itmcnt + 1;
			}
		} catch (Exception E) {
			Assert.fail();
		}
		return itmcnt;
	}

	public static void uncheckCheckbox(String element) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement elem = driver.findElement(By.xpath(element));
			if (elem.getAttribute("class").contains("checked")) {
				String id = elem.getAttribute("id");
				driver.findElement(By.id(id)).click();
			}
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static void clearCache() throws Exception, IOException {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.get("chrome://settings/clearBrowserData");
			Thread.sleep(2000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_TAB();
			Thread.sleep(1000);
			sendKeys_ENTER();
			driver.get(Config.getPropertyValue("url"));
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void clickJS(WebElement elem) {
		try {
			driver = DriverClass.getcurrentDriver();
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", elem);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void isDisplayed(By by, String cont) {
		try {
			driver = DriverClass.getcurrentDriver();
			waitVisible(by);
			WebElement element = driver.findElement(by);
			element.isDisplayed();
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	

	

	/*
	 * public static void assertEquals(String attribute, String value) { try { if
	 * (attribute.equalsIgnoreCase(value)) //TestReport.log(LogStatus.PASS,
	 * "Element has the correct attribute"); else TestReport.log(LogStatus.FAIL,
	 * "Element dooesn't has the correct attribure"); } catch (Exception e) {
	 * Assert.fail(); DriverClass.getcurrentDriver().quit(); } }
	 */

	public static void clickJquery(String query) {
		driver = DriverClass.getcurrentDriver();
		((JavascriptExecutor) driver).executeScript("return jQuery('" + query + "').get(0)");
	}

	public static void scollToPageEnd() {
		driver = DriverClass.getcurrentDriver();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0,document.body.scrollHeight);");
	}

	public static void switchNewWindow() {
		driver = DriverClass.getcurrentDriver();

		try {
			Set<String> newwindows = driver.getWindowHandles();
			String CurWindow = (String) newwindows.toArray()[newwindows.size() - 1];
			driver.switchTo().window(CurWindow);
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void switch_Window() {
		driver = DriverClass.getcurrentDriver();

		try {
			Set<String> win = driver.getWindowHandles();
			int i = 0;
			for (String w : win) {
				if (i == 1) {
					driver.switchTo().window(w);
					break;
				}
				if (i == 0) {
					driver.switchTo().window(w);
					// String parent=w;
					i = i + 1;
					// TestReport.log(LogStatus.PASS, "Switch window");
				}

			}

		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void brokenLinkValidation(String URL) {
		// System.out.println("inside broken link");
		int response = getResponseCode(URL);
		if (response == 200) {
			// System.out.println("working 200");
		} else {
			// System.out.println("not working NOT 200");
			Assert.fail();
		}
	}

	public static int getResponseCode(String urlString) {
		try {
			URL u = new URL(urlString);
			HttpURLConnection h = (HttpURLConnection) u.openConnection();
			h.setRequestMethod("GET");
			h.connect();
			if (h.getResponseCode() == 301 || h.getResponseCode() == 302 || h.getResponseCode() == 307) {
				String newUrl = h.getHeaderField("Location");
				u = new URL(newUrl);
				h = (HttpURLConnection) u.openConnection();
				h.setRequestMethod("GET");
				h.connect();
			}
			return h.getResponseCode();
		} catch (MalformedURLException e) {
			Assert.fail();
			return -1;
		} catch (IOException e) {
			Assert.fail();
		}
		return 0;
	}

	public static void assertContainsData(WebElement web, String string) {
		try {
			if (web.getText().isEmpty())
			Assert.fail();
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public static void reloadPage() {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.navigate().refresh();
			waitForPageLoad();
		} catch (Exception e) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void dropdown(WebElement ele, String keysToSend) {
		if (!(keysToSend == null)) {
			try {
				Select sel = new Select(ele);
				sel.selectByVisibleText(keysToSend);
			} catch (Exception E) {
				Assert.fail();
				DriverClass.getcurrentDriver().quit();
				E.printStackTrace();
			}
		} else {
			
		}
	}

	public static void selectfromDropdownlist(List<WebElement> list, String value) {
		if (!(value == null)) {
			try {
				for (int i = 0; i <= list.size() - 1; i++) {
					if (list.get(i).getText().contains(value)) {
						list.get(i).click();
						break;
					}
				}
			} catch (Exception E) {
				Assert.fail();
				DriverClass.getcurrentDriver().quit();
				E.printStackTrace();
			}
		} 
	}

	public static void tabEnter() {
		try {
			driver = DriverClass.getcurrentDriver();
			Actions act = new Actions(driver);
			act.sendKeys(Keys.TAB);
			// System.out.println("tab entered");
		} catch (Exception E) {
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void Keys_TAB(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.findElement(by).sendKeys(Keys.TAB);
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static void sendKeys_TAB() {
		try {
			Actions actions = new Actions(DriverClass.getcurrentDriver());
			actions.sendKeys(Keys.TAB).build().perform();
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static void sendKeys_ENTER() {
		try {
			Actions actions = new Actions(DriverClass.getcurrentDriver());
			actions.sendKeys(Keys.ENTER).build().perform();
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static List<String> getDropdownValues(By by) {
		WebElement element = findElement(by);
		Select sel = new Select(element);
		// return
		// sel.getOptions().stream().map(e->e.getText()).collect(Collectors.toList());
		return null;
	}

	public static void selectByValue(WebElement clienAddrState, String value) {
		try {
			if (!value.isEmpty() | !(value == null)) {
				Select sel = new Select(clienAddrState);
				sel.selectByValue(value);
			}
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
		}
	}

	public static void selectByText(By by, String value) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			// element.click();
			Select sel = new Select(element);
			sel.selectByVisibleText(value);
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
		}
	}

	public static void selectByIndex(By by, int index) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			Select sel = new Select(element);
			sel.selectByIndex(index);
		} catch (Exception E) {
			Assert.fail();
		}
	}

	public static int getAllOptionsSize(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			Select sel = new Select(element);
			return sel.getOptions().size();
		} catch (Exception E) {
			return 0;
		}
	}

	public static List<WebElement> getAllOptions(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			Select sel = new Select(element);
			return sel.getOptions();
		} catch (Exception E) {
			return null;
		}
	}

	public static String getSelectedOptions(By by) {
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			Select sel = new Select(element);
			return sel.getFirstSelectedOption().getText().toString();
		} catch (Exception E) {
			return "";
		}
	}

	public static List<String> getOptions(By by) {
		// WebDriver driver = DriverClass.getcurrentDriver();
		WebElement element = findElement(by);
		Select sel = new Select(element);
		// return
		// sel.getOptions().stream().map(e->e.getText().trim()).collect(Collectors.toList());
		return null;
	}

	

	public static void chooseOptionWithoutSelect(String iconElements, String icon) {
		try {
			driver = DriverClass.getcurrentDriver();
			List<WebElement> allOptions = findElements(By.xpath(iconElements));
			for (int i = 0; i <= allOptions.size() - 1; i++) {

				if (allOptions.get(i).getText().contains(icon)) {

					allOptions.get(i).click();
					break;

				}
			}
		} catch (Exception E) {
			E.printStackTrace();
		}
	}

//	public static List<WebElement> getListOfWebElements(String element) {
//		List<WebElement> allOptions = null;
//		try {
//			driver = DriverClass.getcurrentDriver();
//			allOptions = findElements(By.xpath(element));
//			
//	            
//		} catch (Exception E) {
//			E.printStackTrace();
//		}
//		return allOptions;
//	}

	public static boolean isEnabled(By by) {
		driver = DriverClass.getcurrentDriver();
		waitVisible(by);
		WebElement element = driver.findElement(by);
		return element.isEnabled();
	}

	public static void getJSDropdown(String dropDown, String elementID) throws Exception {
		driver = DriverClass.getcurrentDriver();
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		System.out.println("js select");
		String dropdownScript = "var select = window.document.getElementById('" + dropDown
				+ "'); for(var i = 0; i < select.options.length; i++){if(select.options[i].text == '" + elementID
				+ "'){ select.options[i].selected = true; } }";

		Thread.sleep(2000);
		System.out.println("dropdownscript");
		executor.executeScript(dropdownScript);
		Thread.sleep(2000);

		String clickScript = "if (" + "\"createEvent\"" + " in document) {var evt = document.createEvent("
				+ "\"HTMLEvents\"" + ");     evt.initEvent(" + "\"change\"" + ", false, true); " + dropDown
				+ ".dispatchEvent(evt); } else " + dropDown + ".fireEvent(" + "\"onchange\"" + ");";

		executor.executeScript(clickScript);
	}

	

	public static boolean isSelected(By by) {
		boolean flag = false;
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			flag = element.isSelected();
			return flag;
		} catch (Exception E) {
			Assert.fail();
			return flag;
		}
	}

	public static boolean isSelected(WebElement webElement) {
		boolean flag = false;
		try {
			// WebDriver driver = DriverClass.getcurrentDriver();
			flag = webElement.isSelected();
			return flag;
		} catch (Exception E) {
			Assert.fail();
			return flag;
		}
	}

	public static boolean JSisEnabled(String button) {
		driver = DriverClass.getcurrentDriver();
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		System.out.println("Inside JS");
		String buttonenabled = "var select = window.document.getElementByXPath('" + button + "').disabled;";
		System.out.println(button);
		Boolean response = (Boolean) executor.executeScript(buttonenabled);
		if (response == true) {
			System.out.println("inside if");
			return response;
		} else {
			System.out.println("inside else");
			return response;
		}
	}

	public static void SwitchFrameByIDName(String IDName) {

		try {
			driver = DriverClass.getcurrentDriver();
			driver.switchTo().frame(IDName);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	public static void SwitchFrameByWebElement(By by) {

		try {

			driver = DriverClass.getcurrentDriver();

			WebElement element = findElement(by);
			driver.switchTo().frame(element);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}

	}

	public static void SwitchToDefaultWebPage() {

		try {
			driver = DriverClass.getcurrentDriver();
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	public static void SetAttribute(By by, String attr_name, String attr_value) {

		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", element, "attr_name",
					"attr_value");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	public static void Action_sendkeys(By by, String Value) {

		try {
			driver = DriverClass.getcurrentDriver();

			WebElement element = findElement(by);

			Actions actions = new Actions(driver);
			actions.moveToElement(element);
			actions.click();
			actions.sendKeys(Value);
			actions.build().perform();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static synchronized void alert_Accept() {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static synchronized void alert_Dismiss() {
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().dismiss();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static synchronized boolean isAlertPresent() {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			Assert.fail();
			return false;
		}
	}

	public static void waitForAngular() {
		WebDriver driver = DriverClass.getcurrentDriver();

		final String script = "var callback = arguments[arguments.length - 1];\n" + "var rootSelector = \'body\';\n"
				+ "var el = document.querySelector(rootSelector);\n" + "\n" + "try {\n" + "    if (angular) {\n"
				+ "        window.angular.getTestability(el).whenStable(callback);\n" + "    }\n" + "    else {\n"
				+ "        callback();\n" + "    }\n" + "} catch (err) {\n" + "    callback(err.message);\n" + "}";

		((JavascriptExecutor) driver).executeAsyncScript(script, new Object[0]);
	}

	public static void scrollToJs(By by) {
		try {
			WebDriver driver = DriverClass.getcurrentDriver();
			WebElement element = findElement(by);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void scrollToBottom(WebDriver driver) {
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public static boolean ischecked(String elem) {
		boolean b = false;
		try {
			driver = DriverClass.getcurrentDriver();
			WebElement element = driver.findElement(By.xpath(elem));
			String str = element.getAttribute("checked");
			if (str.equalsIgnoreCase("true")) {
				b = true;
				return b;
			} else {
				b = false;
				return b;
			}
		} catch (Exception e) {
		}
		return b;
	}

	public static Boolean IsdisplayedElem(By LocatorValue) {
		Boolean ObjectExist = null;
		driver = DriverClass.getcurrentDriver();

		if (driver.findElement(LocatorValue).isDisplayed()) {
			ObjectExist = true;
			System.out.println("is displaying");
			return ObjectExist;
		} else {
			ObjectExist = false;
			return ObjectExist;
		}
	}

	public static boolean verifyElementAbsent(By locator) throws Exception {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.findElement(locator);
			System.out.println("Element Present");
			return false;
		} catch (NoSuchElementException e) {
			System.out.println("Element absent");
			Assert.fail();
			return true;
		}
	}

	public static String getCurrentURL() {
		try {
			driver = DriverClass.getcurrentDriver();
			return driver.getCurrentUrl();
		} catch (Exception e) {
			Assert.fail();
			return null;
		}
	}

	public static void navigateBack() {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.navigate().back();
		} catch (Exception e) {
			return;
		}
	}

	public static void navigateTo(String url) {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.navigate().to(url);
		} catch (Exception e) {
			return;
		}
	}

	public static void refresh() {
		try {
			driver = DriverClass.getcurrentDriver();
			driver.navigate().refresh();
		} catch (Exception e) {
			return;
		}
	}

	public static void writeAccProperty(String TestScenarioID, String AccNO) {
		Properties prop = new Properties();
		InputStream input = null;
		FileOutputStream fr = null;
		String filename = "src/main/resources/AccountInfo.properties";
		try {
			input = new FileInputStream(filename);
			if (input == null) {
				System.out.println("Sorry, unable to find " + filename);
				return;
			}
			prop.load(input);
			prop.setProperty(TestScenarioID, AccNO);
			fr = new FileOutputStream(filename);
			prop.store(fr, "Storing Account Number Into Property File.");
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void mouseClick() {
		try {
			Actions actions = new Actions(DriverClass.getcurrentDriver());
			actions.moveByOffset(100, 150).click().build().perform();
			actions.moveByOffset(0, 0).build().perform();
		} catch (Exception E) {
			E.printStackTrace();
			Assert.fail();
			DriverClass.getcurrentDriver().quit();
		}
	}

	public static void driverClose() {
		driver = DriverClass.getcurrentDriver();
		driver.close();
	}

	public static void sendkKeysJs(String input, By ele) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) DriverClass.getcurrentDriver();
			js.executeScript("arguments[0].value='" + input + "';", ele);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static String getAlertText() {
		
		try {
			driver = DriverClass.getcurrentDriver();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.alertIsPresent());
			String ele=driver.switchTo().alert().getText();
			return ele.toString().trim();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	public static void getHighlightedFieldRed(By by) {
		WebElement element = findElement(by);
		String color = element.getCssValue("color");
		Assert.assertEquals("rgba(0, 0, 0, 0.87)", color);
	}
		
	}





