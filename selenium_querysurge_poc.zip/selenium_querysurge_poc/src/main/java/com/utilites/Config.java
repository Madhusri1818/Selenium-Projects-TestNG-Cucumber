package com.utilites;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Config {
	public static Properties prop = new Properties();
	public static String filepath;
	public static String getPropertyValue(String key) throws FileNotFoundException, IOException {
	
			filepath = System.getProperty("user.dir")+"//src//test//resources//config.properties";
			prop.load(new FileInputStream(filepath));				
		
	

		return prop.getProperty(key);
	}
	public static void main(String[] args) throws FileNotFoundException, IOException {
		System.out.println(Config.getPropertyValue("url"));
	}
}
