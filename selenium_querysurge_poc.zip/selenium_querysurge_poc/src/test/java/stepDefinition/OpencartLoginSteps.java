package stepDefinition;

import com.webelements.WebElementsPage;

import DataBaseConnection.ConnectDB;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OpencartLoginSteps {
	  WebElementsPage pageObject;

	@Given("user Launch Application")
	public void user_launch_application() {
		pageObject = new WebElementsPage();
	}

	@When("user enters username and password")
	public void user_enters_username_and_password() {
		pageObject.EnterData(ConnectDB.ConnectionDB("username"),ConnectDB.ConnectionDB("password"));
	}

	@Then("user click on Login")
	public void user_click_on_login() throws Exception {
		pageObject.Login();
	}

}
