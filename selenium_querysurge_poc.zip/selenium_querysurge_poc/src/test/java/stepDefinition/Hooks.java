package stepDefinition;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.google.common.io.Files;
import com.utilites.Config;
import com.utilites.DriverClass;
import com.utilites.ScreenRecorderUtil;

import io.cucumber.core.logging.Logger;
import io.cucumber.core.logging.LoggerFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.qameta.allure.Allure;

public class Hooks {
	Scenario scenario;
	public static  Logger logger;
	@Before(order = 0)
	public void setup(Scenario scenario) throws Exception, IOException {
		logger =LoggerFactory.getLogger(OpencartLoginSteps.class);
		this.scenario = scenario;
		DriverClass.getDriver(Config.getPropertyValue("browser"));
		String name=scenario.getName().replaceAll(" ", "_");
		ScreenRecorderUtil.startRecord(name);
	}

	@After(order=1)
	public void tearDown() {
		if (scenario.isFailed()) {
			scenario.log(scenario.getName());

			scenario.attach(((TakesScreenshot) DriverClass.getcurrentDriver()).getScreenshotAs(OutputType.BYTES), "",
					"image/jpeg");

		} else {

			scenario.attach(((TakesScreenshot) DriverClass.getcurrentDriver()).getScreenshotAs(OutputType.BYTES), "",
					"image/jpeg");

		}

		DriverClass.getcurrentDriver().quit();
	
}
	
	@After(order = 0)
	public void loggingOff() throws Exception {
		
		ScreenRecorderUtil.stopRecord();	
		}
}
