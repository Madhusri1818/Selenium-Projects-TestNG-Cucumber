package DataBaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class ConnectDB {
	
	public static String ConnectionDB(String text) {
	 String JDBC_Driver = "com.mysql.jdbc.Driver"; // Corrected typo
     String DB_Url = "jdbc:mysql://localhost:3306/opencart";

     final String user = "root";
     final String password = "Kanna@123";

     Connection connect = null;
     Statement statement = null;
     ResultSet resultSet = null;
     String result = null; // Variable to hold the result

    try {
         Class.forName(JDBC_Driver);
         connect = DriverManager.getConnection(DB_Url, user, password);
         statement = connect.createStatement();
         String sqlquery = "select * from LoginData";
         resultSet = statement.executeQuery(sqlquery);
         if (resultSet.next()) {
             if ("username".equals(text)) {
                 result = resultSet.getString("username");
             } else if ("password".equals(text)) {
                 result = resultSet.getString("password");
             } else {
                 // Handle invalid input
                 result = "Invalid input";
             }
         } else {
             result = "No records found for the given username.";
         }
    }catch (ClassNotFoundException | SQLException e) {
             e.printStackTrace();
         } finally {
             // Close resources in finally block to ensure they are always closed
             try {
                 if (resultSet != null) resultSet.close();
                 if (statement != null) statement.close();
                 if (connect != null) connect.close();
             } catch (SQLException e) {
                 e.printStackTrace();
             }
         }
         
         return result; // Return the result
     }
 public static void main(String[] args) throws Exception {
     String username = ConnectionDB("username");
     String password = ConnectionDB("password");

     // Print or use the retrieved values
     System.out.println("Username: " + username);
     System.out.println("Password: " + password);
 }
}
